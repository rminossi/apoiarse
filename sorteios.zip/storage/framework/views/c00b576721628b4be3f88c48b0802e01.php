<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">

    <?php if (! empty(trim($__env->yieldContent('css')))): ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php endif; ?>

<link rel="stylesheet" href="/assets/backend/css/reset.css" />
<link rel="stylesheet" href="/assets/backend/css/vendor.css" />
<link rel="stylesheet" href="/assets/backend/css/boot.css" />
<link rel="stylesheet" href="/assets/backend/css/style.css" />

    <link rel="shortcut icon" href="<?php echo e(url(asset('/assets/frontend/images/favicon.png'))); ?>">
<script src="/assets/backend/js/jquery.js"></script>
<script src="/assets/backend/js/vendor.js"></script>
<script src="/assets/backend/js/scripts.js"></script>
    <script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <meta name="csrf-token" content="<?php echo e(@csrf_token()); ?>">

    <title>Rifa Online - Painel Administrativo</title>
</head>

<body>

    <div class="ajax_load">
        <div class="ajax_load_box">
            <div class="ajax_load_box_circle"></div>
            <p class="ajax_load_box_title">Aguarde, carregando...</p>
        </div>
    </div>

    <div class="ajax_response"></div>

    <div class="dash">
        <aside class="dash_sidebar">
            <article class="dash_sidebar_user">
                <img class="dash_sidebar_user_thumb" src="<?php echo e(url(asset('/assets/backend/images/round.png'))); ?>" alt="" title="" />

                <h1 class="dash_sidebar_user_name">
                    <a href="">Rifa Online</a>
                </h1>
            </article>

            <ul class="dash_sidebar_nav">
                <li class="dash_sidebar_nav_item <?php echo e(isActive('admin.home')); ?>">
                    <a class="icon-tachometer" href="<?php echo e(route('admin.home')); ?>">Dashboard</a>
                </li>
                <li class="dash_sidebar_nav_item <?php echo e(isActive('admin.customers')); ?>"><a class="icon-users" href="<?php echo e(route('admin.customers.index')); ?>">Clientes</a></li>
                <li class="dash_sidebar_nav_item <?php echo e(isActive('admin.rifas.index')); ?>"><a class="icon-table" href="<?php echo e(route('admin.rifas.index')); ?>">Rifas</a>
                    <ul class="dash_sidebar_nav_submenu">
                        <li class="<?php echo e(isActive('admin.rifas.index')); ?>"><a href="<?php echo e(route('admin.rifas.index')); ?>">Ver Todas</a></li>
                        <li class="<?php echo e(isActive('admin.rifas.create')); ?>"><a href="<?php echo e(route('admin.rifas.create')); ?>">Criar Nova</a></li>
                    </ul>
                </li>
                <li class="dash_sidebar_nav_item <?php echo e(isActive('admin.sites')); ?>"><a class="icon-pencil" href="<?php echo e(route('admin.site.edit', ['site' => '1'])); ?>">Configurações do site</a></li>
                <li class="dash_sidebar_nav_item"><a class="icon-reply" href="<?php echo e(route('web.home')); ?>">Ver Site</a></li>
                <li class="dash_sidebar_nav_item"><a class="icon-sign-out on_mobile" href="<?php echo e(route('admin.logout')); ?>" target="_blank">Sair</a></li>
            </ul>

        </aside>

        <section class="dash_content">

            <div class="dash_userbar">
                <div class="dash_userbar_box">
                    <div class="dash_userbar_box_content">
                        <span class="icon-align-justify icon-notext mobile_menu transition btn btn-green"></span>
                        <h1 class="transition">
                            <a href="<?php echo e(route('admin.home')); ?>">
                                <img src="<?php echo e(url(asset('assets/frontend/images/sorteios_logo.png'))); ?>" width="150">
                            </a>
                        </h1>
                        <div class="dash_userbar_box_bar no_mobile">
                            <a class="text-red icon-sign-out" href="<?php echo e(route('admin.logout')); ?>">Sair</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="dash_content_box">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </div>


    <?php if (! empty(trim($__env->yieldContent('js')))): ?>
    <?php echo $__env->yieldContent('js'); ?>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/admin/master/master.blade.php ENDPATH**/ ?>
