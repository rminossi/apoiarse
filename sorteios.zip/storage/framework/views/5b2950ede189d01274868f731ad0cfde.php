
<?php $__env->startSection('content'); ?>
<section class="dash_content_app">

    <header class="dash_content_app_header">
        <h2 class="icon-search">Filtro</h2>
        <div class="dash_content_app_header_actions">
            <nav class="dash_content_app_breadcrumb">
                <ul>
                    <li><a href="">Dashboard</a></li>
                    <li class="separator icon-angle-right icon-notext"></li>
                    <li><a href="">Rifas</a></li>
                    <li class="separator icon-angle-right icon-notext"></li>
                    <li><a href="" class="text-orange">Filtro</a></li>
                </ul>
            </nav>

            <a href="<?php echo e(route('admin.rifas.create')); ?>" class="btn btn-orange icon-plus ml-1">Criar Rifa</a>
        </div>
    </header>

    <div class="dash_content_app_box">
        <?php if(session()->exists('message')): ?>
            <div class="message message-green">
                <p class="icon-asterisk"><?php echo e(session()->get('message')); ?></p>
            </div>
        <?php endif; ?>
        <div class="dash_content_app_box_stage">
            <div class="realty_list">
                <?php $__currentLoopData = $rifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="realty_list_item mt-1 mb-1">
                        <div class="realty_list_item_actions_stats">
                            <img src="<?php echo e(url($rifa->cover())); ?>" alt="">
                        </div>
                        <div class="realty_list_item_content">
                            <h4><?php echo e($rifa->title); ?></h4>
                            <div class="realty_list_item_card">
                                <div class="realty_list_item_card_image">
                                    <span class="icon-table"></span>
                                </div>
                                <div class="realty_list_item_card_content">
                                    <span class="realty_list_item_description_title">Cotas:</span>
                                    <span class="realty_list_item_description_content"><?php echo e($rifa->q_numbers); ?></span>
                                </div>
                            </div>
                            <div class="realty_list_item_card">
                                <div class="realty_list_item_card_image">
                                    <span class="icon-money"></span>
                                </div>
                                <div class="realty_list_item_card_content">
                                    <span class="realty_list_item_description_title">Valor da cota:</span>
                                    <span class="realty_list_item_description_content"><?php echo e($rifa->price); ?></span></span>
                                </div>
                            </div>
                            <div class="realty_list_item_card">
                                <div class="realty_list_item_card_image">
                                    <span class="icon-bar-chart"></span>
                                </div>
                                <div class="realty_list_item_card_content">
                                    <span class="realty_list_item_description_title">Cotas Pagas:</span>
                                    <span class="realty_list_item_description_content"><?php echo e($rifa->numbers()->where('status', '3')->count()); ?></span></span>
                                </div>
                            </div>
                            <div class="realty_list_item_card">
                                <div class="realty_list_item_card_image">
                                    <span class="icon-bar-chart"></span>
                                </div>
                                <div class="realty_list_item_card_content">
                                    <span class="realty_list_item_description_title">Cotas Disponíveis:</span>
                                <span class="realty_list_item_description_content"><?php echo e($rifa->numbers()->where('status', '1')->count()); ?></span></span>
                                </div>
                            </div>
                            <div class="realty_list_item_card">
                                <div class="realty_list_item_card_image">
                                    <span class="icon-bar-chart"></span>
                                </div>
                                <div class="realty_list_item_card_content">
                                    <span class="realty_list_item_description_title">Cotas Reservadas:</span>
                                    <span class="realty_list_item_description_content"><?php echo e($rifa->numbers()->where('status', '2')->count()); ?></span></span>
                                </div>
                            </div>
                            <?php if($rifa->winner_number): ?>
                                        <div class="realty_list_item_card">
                                            <div class="realty_list_item_card_image">
                                                <span class="icon-realty-garage"></span>
                                            </div>
                                            <div class="realty_list_item_card_content">
                                                <span class="realty_list_item_description_title">Vencedor:</span>
                                                <span class="realty_list_item_description_content"><?php echo e($rifa->winner_number); ?></span></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                        </div>
                        <div class="realty_list_item_actions mt-1">
                            <div class="ml-auto d-flex">
                                <a href="<?php echo e(route('admin.rifas.edit', ['rifa' => $rifa->id])); ?>" class="btn btn-green icon-pencil-square-o">Editar Rifa</a>
                                <form method="POST" action="<?php echo e(route('admin.rifas.update', ['rifa' => $rifa->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                    <button class="btn btn-red icon-trash-o" type="submit">Excluir Rifa</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/admin/rifas/index.blade.php ENDPATH**/ ?>