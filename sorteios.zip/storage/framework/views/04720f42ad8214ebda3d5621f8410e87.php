	
	<?php $__env->startSection('content'); ?>
		<div class="fh5co-hero fh5co-hero-2">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover fh5co-cover_2 text-center" data-stellar-background-ratio="0.5" style="background-image: url('<?php echo e(asset('assets/frontend/images/cover_bg_1.jpg')); ?>');">
				<div class="desc animate-box">
					<h2><strong>Fale</strong> conosco</h2>
					<span>Preencha o formulário abaixo, nos mande uma mensagem,<br /> e nos siga nas redes sociais.</span>
				</div>
			</div>
		</div>
		<!-- end:header-top -->

		<div id="fh5co-contact" class="animate-box">
			<div class="container">
			<form action="<?php echo e(route('enviar-contato')); ?>" method="POST">
					<?php echo csrf_field(); ?>
                <?php if(isset($site)): ?>
					<div class="row">
						<div class="col-md-6">
							<h3 class="section-title">Onde Estamos,</h3>
							<ul class="contact-info">
								<li><i class="icon-location-pin"></i>Torres, RS</li>
                                <li><i class="icon-phone2"></i><a target="_blank" href="https://api.whatsapp.com/send?phone=5551996757224"><?php echo e($site->phone); ?></a></li>
								<li><i class="icon-mail"></i><a target="_blank" href="mailto:contato@emicegarage.com.br"><?php echo e($site->email); ?></a></li>
								<li><i class="icon-instagram"></i><a target="_blank" href="https://www.instagram.com/emicegarage">www.instagram.com/seusorteio</a></li>
							</ul>
						</div>
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<input type="text" name="fullname" class="form-control" placeholder="Nome">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<input type="text" name="email" class="form-control" placeholder="Email">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<input type="text" name="phone" class="form-control" placeholder="Telefone">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<textarea name="message" class="form-control" id="message" cols="30" rows="7" placeholder="Mensagem"></textarea>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="submit" value="Enviar" class="btn btn-primary">
									</div>
								</div>
							</div>
						</div>
					</div>
                <?php endif; ?>
				</form>
			</div>
		</div>
		<!-- END map -->
		<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/web/contato.blade.php ENDPATH**/ ?>