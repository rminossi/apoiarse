
<?php $__env->startSection('content'); ?>
<div class="fh5co-hero fh5co-hero-2">
    <div class="fh5co-overlay"></div>
    <div class="fh5co-cover fh5co-cover_2 text-center" data-stellar-background-ratio="0.5" style="background-image: url('<?php echo e(asset('assets/images/cover_bg_1.jpg')); ?>');";">
        <div class="desc animate-box">
            <h2><strong>Nossas Rifas</strong></h2>
            <span>Confira abaixo as nossas rifas atuais e também as finalizadas.</span>
        </div>
    </div>
</div>
<!-- end:header-top -->
<div id="fh5co-portfolio">
    <div class="container">
        <?php if(sizeof($activeRifas) > 0): ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center heading-section animate-box">
                <h3>Rifas Ativas</h3>
                <p>Confira nossas rifas ativas, o que significa que ainda dá tempo de adquirir os seus números para o sorteio!</p>
            </div>
        </div>
        <?php if(isset($activeRifas)): ?>
        <div class="row row-bottom-padded-md">
            <div class="col-md-12">
                <ul id="fh5co-portfolio-list">
                    <?php $__currentLoopData = $activeRifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4">
                        <div class="fh5co-blog animate-box">
                            <a href="<?php echo e(route('web.rifa', ['slug' => $rifa->slug])); ?>"><img class="img-responsive" src="<?php echo e(url($rifa->cover())); ?>" alt=""></a>
                            <div class="blog-text">
                                <div class="prod-title">
                                    <h3><a href="" #><?php echo e($rifa->title); ?></a></h3>
                                    <!-- exibir primeiros 50 caracteres da descrição da rifa -->

                                    <p><?php echo html_entity_decode(substr($rifa->description, 0, 139)); ?></p>
                                    <a href="<?php echo e(route('web.rifa', ['slug' => $rifa->slug])); ?>" class="btn btn-primary"><?php echo e("Cota - R$".$rifa->price); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <?php if(sizeof($finishedRifas) > 0): ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center heading-section animate-box">
                <h3>Rifas Encerradas</h3>
                <p>Confira nossas rifas encerradas.</p>
            </div>
        </div>
        <?php if(isset($finishedRifas)): ?>
        <div class="row row-bottom-padded-md">
            <div class="col-md-12">
                <ul id="fh5co-portfolio-list">
                    <?php $__currentLoopData = $finishedRifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4">
                        <div class="fh5co-blog animate-box">
                            <a href="<?php echo e(route('web.rifa', ['slug' => $rifa->slug])); ?>"><img class="img-responsive" src="<?php echo e(url($rifa->cover())); ?>" alt=""></a>
                            <div class="blog-text">
                                <div class="prod-title">
                                    <h3><a href="" #><?php echo e($rifa->title); ?></a></h3>
                                    <p><?php echo e($rifa->description); ?></p>
                                    <a href="" class="btn btn-primary"><?php echo e("Comprar - R$".$rifa->price); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<script>
    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the button, open the modal
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/web/rifas.blade.php ENDPATH**/ ?>