		<!-- fh5co-blog-section -->
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a target="_blank" href="https://api.whatsapp.com/send?phone=5551996757224"><i class="icon-whatsapp"></i></a>
								<a target="_blank" href="https://www.instagram.com/emicegarage"><i class="icon-instagram"></i></a>
							</p>
							<p>&copy; <?= date("Y"); ?> - Todos os direitos reservados. <br>Desenvolvido por <a href="https://ceossistemas.com.br" target="_blank">Ceos Sistemas</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>
		</div>
		</div>
		</body>

		</html><?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/web/includes/footer.blade.php ENDPATH**/ ?>