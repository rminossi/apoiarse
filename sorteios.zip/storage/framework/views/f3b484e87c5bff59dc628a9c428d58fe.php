
<?php $__env->startSection('content'); ?>
<div class="fh5co-hero">
	<div class="fh5co-overlay"></div>
	<div class="fh5co-cover text-center" data-stellar-background-ratio="0.5" style="background-image: url(<?php echo e(asset('assets/frontend/images/cover_bg_1.jpg')); ?>);">
		<div class="desc animate-box">
			<h2>Venha <strong>ganhar</strong> conosco</h2>
			<span><a class="btn btn-primary btn-lg" href="<?php echo e(route('web.rifas')); ?>">Ver nossas rifas</a></span>
		</div>
	</div>
</div>
<?php if(isset($activeRifas)): ?>
<div id="fh5co-blog-section" class="fh5co-section-gray">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
				<h3>Próximos sorteios</h3>
				<p>Confira aqui nossos próximos sorteios em destaque e garanta seus números!</p>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row row-bottom-padded-md">
			<?php $__currentLoopData = $activeRifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-4 col-md-4">
				<div class="fh5co-blog animate-box">
					<a href="<?php echo e(route('web.rifa', ['slug' => $rifa->slug])); ?>"><img class="img-responsive" src="<?php echo e(url($rifa->cover())); ?>" alt=""></a>
					<div class="blog-text">
						<div class="prod-title">
							<h3><a href="" #><?php echo e($rifa->title); ?></a></h3>
							<p><?php echo html_entity_decode(substr($rifa->description, 0, 139)); ?></p>
							<a href="<?php echo e(route('web.rifa', ['slug' => $rifa->slug])); ?>" class="btn btn-primary"><?php echo e("Cota - R$".$rifa->price); ?></a>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="row">
			<div class="col-md-4 col-md-offset-4 text-center animate-box">
				<a href="<?php echo e(route('web.rifas')); ?>" class="btn btn-primary btn-lg">Ver Todos</a>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<?php if(sizeof($finishedRifas) > 0): ?>
<div id="fh5co-blog-section" class="fh5co-section-gray">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
				<h3>Sorteios encerrados</h3>
				<p>Veja nossos últimos sorteios realizados, seus detalhes e ganhadores.</p>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row row-bottom-padded-md">
			<?php $__currentLoopData = $finishedRifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-4 col-md-4">
				<div class="fh5co-blog animate-box">
					<a href=""><img class="img-responsive" src="<?php echo e(url($rifa->cover())); ?>" alt=""></a>
					<div class="blog-text">
						<div class="prod-title">
							<h3><a href="" #><?php echo e($rifa->title); ?></a></h3>
							<p><?php echo e($rifa->description); ?></p>
							<a href="" class="btn btn-primary"><?php echo e("Comprar - R$".$rifa->price); ?></a>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="row">
			<div class="col-md-4 col-md-offset-4 text-center animate-box">
				<a href="" class="btn btn-primary btn-lg">Ver Todos</a>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/web/home.blade.php ENDPATH**/ ?>