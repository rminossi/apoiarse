
<?php $__env->startSection('content'); ?>
    <section class="dash_content_app">
        <header class="dash_content_app_header">
            <h2 class="icon-search">Editar Rifa</h2>

            <div class="dash_content_app_header_actions">
                <nav class="dash_content_app_breadcrumb">
                    <ul>
                        <li><a href="">Dashboard</a></li>
                        <li class="separator icon-angle-right icon-notext"></li>
                        <li><a href="">Rifa</a></li>
                        <li class="separator icon-angle-right icon-notext"></li>
                        <li><a href="" class="text-orange">Cadastrar Rifa</a></li>
                    </ul>
                </nav>
            </div>
        </header>
        <?php echo $__env->make('admin.rifas.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dash_content_app_box">
            <div class="nav">
                <?php if($errors->all()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="message message-red">
                            <p class="icon-asterisk"><?php echo e($error); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(session()->exists('message')): ?>
                    <div class="message message-green">
                        <p class="icon-asterisk"><?php echo e(session()->get('message')); ?></p>
                    </div>
                <?php endif; ?>
                <ul class="nav_tabs">
                    <li class="nav_tabs_item">
                        <a href="#data" class="nav_tabs_item_link active">Dados da Rifa</a>
                    </li>
                    <li class="nav_tabs_item">
                        <a href="#photos" class="nav_tabs_item_link">Fotos</a>
                    </li>
                    <li class="nav_tabs_item">
                        <a href="#numbers" class="nav_tabs_item_link">Números</a>
                    </li>
                </ul>
                <form class="app_form" action="<?php echo e(route('admin.rifas.update', ['rifa' => $rifa->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="nav_tabs_content">
                        <div id="data">
                            <label class="label">
                                <span class="legend">*Título Site:</span>
                                <input type="text" name="title" placeholder="Insira o título da rifa" value="<?php echo e(old('title') ?? $rifa->title); ?>"/>
                            </label>
                            <div class="label">
                                <label class="label">
                                    <span class="legend">*Descrição do Sorteio:</span>
                                    <textarea name="description" cols="30" rows="10" id="mytextarea"><?php echo e(old('description') ?? $rifa->description); ?></textarea>
                                </label>
                            </div>
                            <div class="label_g2">
                                <label class="label">
                                    <span class="legend">*Tipo:</span>
                                    <select name="type">
                                        <option <?php echo e((old('type') == 'car' ? 'selected' : ($rifa->type === 'car' ? 'selected': ''))); ?> value="car">Carro</option>
                                        <option <?php echo e((old('type') == 'motorcycle' ? 'selected' : ($rifa->type === 'motorcycle' ? 'selected': ''))); ?> value="motorcycle">Moto</option>
                                    </select>
                                </label>
                                <label class="label">
                                    <span class="legend">*Marca/Modelo:</span>
                                    <input type="text" name="model" placeholder="Volkswagem Golf GTI" value="<?php echo e(old('model') ?? $rifa->model); ?>"/>
                                </label>
                                <label class="label ml-2">
                                    <span class="legend">*Situação:</span>
                                    <select name="prize_status">
                                        <option value="new" <?php echo e((old('prize_status') == 'new' ? 'selected' : ($rifa->prize_status === 'new' ? 'selected': ''))); ?>>Novo</option>
                                        <option value="used" <?php echo e((old('prize_status') == 'used' ? 'selected' : ($rifa->prize_status === 'used' ? 'selected': ''))); ?>>Seminovo</option>
                                    </select>
                                </label>
                            </div>
                            <div class="label_g4">
                                <label class="label">
                                    <span class="legend">*Quantidade de Cotas:</span>
                                    <input type="number" name="q_numbers" placeholder="Ex: 1000"
                                           value="<?php echo e(old('q_numbers') ?? $rifa->q_numbers); ?>"
                                           <?php echo e($rifa->q_numbers ? 'disabled' : ''); ?>/>
                                </label>
                                <label class="label mr-2">
                                    <span class="legend">Valor da Cota:</span>
                                    <input type="text" name="price" placeholder="Ex: R$ 100,00"
                                           value="<?php echo e(old('price') ?? $rifa->price); ?>"/>
                                </label>
                                <label class="label">
                                    <span class="legend">*Status:</span>
                                    <select name="status">
                                        <option value="1" <?php echo e((old('status') == '1' ? 'selected' : ($rifa->status === '1' ? 'selected': ''))); ?>>Ativo</option>
                                        <option value="2" <?php echo e((old('status') == '2' ? 'selected' : ($rifa->status === '2' ? 'selected': ''))); ?>>Inativo</option>
                                        <option value="3" <?php echo e((old('status') == '3' ? 'selected' : ($rifa->status === '3' ? 'selected': ''))); ?>>Encerrada</option>
                                    </select>
                                </label>
                                <label class="label">
                                    <?php echo e(old('modality')); ?>

                                    <span class="legend">*Modalidade:</span>
                                    <select name="modality" id="modality">
                                        <option value="1" <?php echo e((old('modality') == '1' ? 'selected' : ($rifa->modality === '1' ? 'selected': ''))); ?>>Número Escolhido</option>
                                        <option value="2" <?php echo e((old('modality') == '2' ? 'selected' : ($rifa->modality === '2' ? 'selected': ''))); ?>>Número Aleatório</option>
                                        <option value="3" <?php echo e((old('modality') == '3' ? 'selected' : ($rifa->modality === '3' ? 'selected': ''))); ?>>Número Aleatório + Fixas</option>
                                    </select>
                                </label>
                            </div>
                            <div id="fixed-numbers" class="d-none">
                                <div class="label">
                                    <label class="label">
                                        <span class="legend">*Cotas Fixas:</span>
                                        <input type="text" name="fixed_numbers" placeholder="Separar por ponto-vírgula Ex: 00000;11111;22222;..."
                                               value="<?php echo e(old('fixed_numbers') ?? $rifa->fixed_numbers); ?>"/>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div id="photos" class="d-none">
                            <div id="images">
                                <label class="label">
                                    <span class="legend">Imagens</span>
                                    <input type="file" name="files[]" multiple>
                                </label>

                                <div class="content_image"></div>

                                <div class="property_image">
                                    <?php $__currentLoopData = $rifa->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="property_image_item">
                                            <img style="object-fit: cover; width: 300px; height: 300px" src="<?php echo e(url('storage/'.$image->image->path)); ?>">
                                            <div class="property_image_actions">
                                                <a href="javascript:void(0)"
                                                   class="btn btn-small <?php echo e(($image->image->cover == true ? 'btn-green' : '')); ?> icon-check icon-notext image-set-cover"
                                                   data-action="<?php echo e(route('admin.rifas.imageSetCover', ['image' => $image->image->id])); ?>"></a>
                                                <a href="javascript:void(0)"
                                                   class="btn btn-red btn-small icon-times icon-notext image-remove"
                                                   data-action="<?php echo e(route('admin.rifas.removeImage', ['image' => $image->image->id])); ?>"></a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div id="numbers" class="d-none">
                            <table id="dataTable" class="nowrap stripe" width="100" style="width: 100% !important;">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Situação</th>
                                    <th>Nome Completo</th>
                                    <th>CPF</th>
                                    <th>Data de Reserva / Confirmação</th>
                                    <th>Ações</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($number->status === 1): ?>
                                        <tr>
                                            <td><?php echo e($number->number); ?></td>
                                            <td class="bg-green">Disponível</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td class="d-flex">
                                                <form method="POST" action="<?php echo e(route('admin.numbers.update', ['number' => $number->id, 'status' => $number->status-1])); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('put')); ?>

                                                    <button type="submit" disabled id="btnCancelar" class="btn btn-red"><i class="icon-trash"></i>Cancelar</button>
                                                </form>
                                                <form method="POST" action="<?php echo e(route('admin.numbers.update', ['number' => $number->id, 'status' => $number->status+1])); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('put')); ?>

                                                    <button type="submit" disabled id="btnConfirnar" class="btn btn-green"><i class="icon-check"></i>Confirmar</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($number->status === 2): ?>
                                        <tr>
                                            <td><?php echo e($number->number); ?></td>
                                            <td class="bg-yellow">Reservado</td>
                                            <td><?php echo e($number->customer->fullName); ?></td>
                                            <td><?php echo e($number->customer->cpf); ?></td>
                                            <td><?php echo e($number->updated_at); ?></td>
                                            <td class="d-flex">
                                                <form method="POST" action="<?php echo e(route('admin.numbers.update', ['number' => $number->id, 'status' => $number->status-1])); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('put')); ?>

                                                    <button type="submit" id="btnCancelar" class="btn btn-red"><i class="icon-trash"></i>Cancelar</button>
                                                </form>
                                                <form method="POST" action="<?php echo e(route('admin.numbers.update', ['number' => $number->id, 'status' => $number->status+1])); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('put')); ?>

                                                    <button type="submit" id="btnConfirnar" class="btn btn-green"><i class="icon-check"></i>Confirmar</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php if($number->status === 3): ?>
                                        <tr>
                                            <td><?php echo e($number->number); ?></td>
                                            <td class="bg-red">Indisponível</td>
                                            <td>><?php echo e($number->customer->fullName); ?></td>
                                            <td><?php echo e($number->customer->cpf); ?></td>
                                            <td><?php echo e($number->updated_at); ?></td>
                                            <td class="d-flex">
                                                <form method="POST" action="<?php echo e(route('admin.numbers.update', ['number' => $number->id, 'status' => $number->status-1])); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('put')); ?>

                                                    <button type="submit" id="btnCancelar" class="btn btn-red"><i class="icon-trash"></i>Cancelar</button>
                                                </form>
                                                <form method="POST" action="<?php echo e(route('admin.numbers.update', ['number' => $number->id, 'status' => $number->status+1])); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('put')); ?>

                                                    <button type="submit" disabled id="btnConfirnar" class="btn btn-green"><i class="icon-check"></i>Confirmar</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="text-right mt-2">
                        <button class="btn btn-large btn-green icon-check-square-o" type="submit">Salvar alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script>
        CKEDITOR.replace( 'description' );
    </script>
    <script>
        $(function () {
            if ($('#modality').val() == 3) {
                $('#fixed-numbers').removeClass('d-none');
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('input[name="files[]"]').change(function (files) {

                $('.content_image').text('');

                $.each(files.target.files, function (key, value) {
                    var reader = new FileReader();
                    reader.onload = function (value) {
                        $('.content_image').append(
                            '<div class="property_image_item">' +
                            '<div class="embed radius" ' +
                            'style="background-image: url(' + value.target.result + '); background-size: cover; background-position: center center;">' +
                            '</div>' +
                            '</div>');
                    };
                    reader.readAsDataURL(value);
                });
            });

            $('.image-set-cover').click(function(event){
                event.preventDefault();

                var button = $(this);

                $.post(button.data('action'), {}, function(response){
                    if(response.success === true) {
                        $('.property_image').find('a.btn-green').removeClass('btn-green');
                        button.addClass('btn-green');
                    }
                }, 'json');
            });

            $('.image-remove').click(function(event){
                event.preventDefault();

                var button = $(this);
                $.ajax({
                    url: button.data('action'),
                    type: 'DELETE',
                    dataType: 'json',
                    success: function(response){
                        if(response.success === true) {
                            button.closest('.property_image_item').fadeOut(function(){
                                $(this).remove();
                            });
                        }
                    }
                })
            });

            $('#modality').change(function () {
                if ($(this).val() == 3) {
                    $('#fixed-numbers').removeClass('d-none');
                } else {
                    $('#fixed-numbers').addClass('d-none');
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rcnahas\Documents\Desenvolvimento\CEOS\sorteios\resources\views/admin/rifas/edit.blade.php ENDPATH**/ ?>