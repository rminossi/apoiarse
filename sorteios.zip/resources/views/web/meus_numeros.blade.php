@extends('web.master.master')
@section('content')
    <div class="fh5co-hero">
        <div class="fh5co-overlay"></div>
        <div class="fh5co-cover text-center" data-stellar-background-ratio="0.5"
             style="background-image: url({{ asset('assets/frontend/images/cover_bg_1.jpg') }});">
            <div class="desc animate-box">
                <h2>Meus Números</h2>
                <span>Verifique seus números</span>
            </div>
        </div>
    </div>
    <div id="fh5co-blog-section" class="fh5co-section-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mb-3 col-md-offset-2 text-center heading-section animate-box">
                    <h3>Consultar números por CPF</h3>
                    <p>Insira o CPF em que foram reservados os números para verificar o status</p>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <form method="" action="/meus-numeros" class="col-md-4 col-md-offset-4 text-center animate-box">
                    <div class="form-group">
                        <input type="text" class="form-control" id="cpf" name="cpf" placeholder="CPF">
                    </div>
                    <button class="btn btn-primary btn-lg">Consultar</button>
                </form>
            </div>
        </div>
        @if(isset($rifas))
            <div class="container">
                <div class="row">
                    <div class="col-md-8 mb-3 col-md-offset-2 text-center heading-section animate-box">
                        <h3>Meus Números</h3>
                    </div>
                </div>
                @foreach($rifas as $rifa)
                    <div class="text-center">
                        <a href="/rifas/{{ $rifa->slug }}"><h3 class="text-center">{{$rifa->title}}</h3></a>
                    </div>
                        <div class="row d-flex my-5">
                            @foreach($customer->numbers->where('rifa_id', $rifa->id)->where('status', 3) as $number)
                            <div class="border border-primary col-md-1 py-3 text-center center m-1">
                                {{ $number->number }}
                            </div>
                            @endforeach
                        </div>
                @endforeach
            </div>
        @endif
    </div>
@endsection
