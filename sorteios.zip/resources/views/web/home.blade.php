@extends('web.master.master')
@section('content')
<div class="fh5co-hero">
	<div class="fh5co-overlay"></div>
	<div class="fh5co-cover text-center" data-stellar-background-ratio="0.5" style="background-image: url({{ asset('assets/frontend/images/cover_bg_1.jpg') }});">
		<div class="desc animate-box">
			<h2>Venha <strong>ganhar</strong> conosco</h2>
			<span><a class="btn btn-primary btn-lg" href="{{route('web.rifas')}}">Ver nossas rifas</a></span>
		</div>
	</div>
</div>
@isset($activeRifas)
<div id="fh5co-blog-section" class="fh5co-section-gray">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
				<h3>Próximos sorteios</h3>
				<p>Confira aqui nossos próximos sorteios em destaque e garanta seus números!</p>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row row-bottom-padded-md">
			@foreach($activeRifas as $rifa)
			<div class="col-lg-4 col-md-4">
				<div class="fh5co-blog animate-box">
					<a href="{{route('web.rifa', ['slug' => $rifa->slug])}}"><img class="img-responsive" src="{{url($rifa->cover())}}" alt=""></a>
					<div class="blog-text">
						<div class="prod-title">
							<h3><a href="" #>{{$rifa->title}}</a></h3>
							<p>{!!html_entity_decode(substr($rifa->description, 0, 139))!!}</p>
							<a href="{{route('web.rifa', ['slug' => $rifa->slug])}}" class="btn btn-primary">{{"Cota - R$".$rifa->price}}</a>
						</div>
					</div>
				</div>
			</div>
			@endforeach
		</div>
		<div class="row">
			<div class="col-md-4 col-md-offset-4 text-center animate-box">
				<a href="{{route('web.rifas')}}" class="btn btn-primary btn-lg">Ver Todos</a>
			</div>
		</div>
	</div>
</div>
@endisset
@if(sizeof($finishedRifas) > 0)
<div id="fh5co-blog-section" class="fh5co-section-gray">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
				<h3>Sorteios encerrados</h3>
				<p>Veja nossos últimos sorteios realizados, seus detalhes e ganhadores.</p>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row row-bottom-padded-md">
			@foreach($finishedRifas as $rifa)
			<div class="col-lg-4 col-md-4">
				<div class="fh5co-blog animate-box">
					<a href=""><img class="img-responsive" src="{{url($rifa->cover())}}" alt=""></a>
					<div class="blog-text">
						<div class="prod-title">
							<h3><a href="" #>{{$rifa->title}}</a></h3>
							<p>{{$rifa->description}}</p>
							<a href="" class="btn btn-primary">{{"Comprar - R$".$rifa->price}}</a>
						</div>
					</div>
				</div>
			</div>
			@endforeach
		</div>
		<div class="row">
			<div class="col-md-4 col-md-offset-4 text-center animate-box">
				<a href="" class="btn btn-primary btn-lg">Ver Todos</a>
			</div>
		</div>
	</div>
</div>
@endif
@endsection
