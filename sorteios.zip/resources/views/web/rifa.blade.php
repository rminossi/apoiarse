@extends('web.master.master')
@section('content')
    @if(!empty($rifa))
        <style>
            /* Modal Header */
            .modal-header {
                padding: 10px 16px;
                background-color: #fefefe;
                border: none;
            }

            /* Modal Body */
            .modal-body {
                padding: 35px 140px;
            }

            @media (max-width: 800px) {
                .modal-body {
                    padding: 35px 50px;
                }
            }

            /* Modal Footer */
            .modal-footer {
                padding: 2px 16px;
                background-color: #fefefe;
                border: none;
            }

            /* Modal Content */
            .modal-content {
                position: relative;
                background-color: #fefefe;
                margin: auto;
                margin-top: 50px !important;
                padding: 0;
                border: 1px solid #888;
                width: 80%;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
                animation-name: animatetop;
                animation-duration: 0.4s;
            }

            /* Add Animation */
            @keyframes animatetop {
                from {
                    top: -300px;
                    opacity: 0
                }

                to {
                    top: 0;
                    opacity: 1
                }
            }
        </style>
        <div class="fh5co-hero fh5co-hero-2">
            <div class="fh5co-overlay"></div>
            <div class="fh5co-cover fh5co-cover_2 text-center" data-stellar-background-ratio="0.5"
                 style="background-image: url({{url($rifa->cover())}}); background-position-y: center;">
                <div class="desc animate-box">
                    <h2>{{$rifa->title}}</h2>
                    <span>{{$rifa->model}}</span>
                    <span><a class="btn btn-primary btn-lg" href="#cotas">Adquirir Cotas</a></span>
                </div>
            </div>
        </div>
        <!-- end:header-top -->

        <div id="fh5co-services-section" class="fh5co-section-gray">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 heading-section animate-box">
                        <h3>{{$rifa->title}}</h3>
                        <p>{!!html_entity_decode($rifa->description)!!}</p>
                        <div class="row text-center">
                            <span><a class="btn btn-primary btn-lg" href="#cotas">Adquirir Cotas</a></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row text-center">
                    @foreach($rifa->images()->get() as $image)
                        <div class="col-md-4 col-sm-4">
                            <img style="object-fit: cover; width: 100%; height: 250px; margin-bottom: 30px"
                                 src="{{url("storage/" . $image->image->path)}}">
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        <div style="padding: 40px" id="fh5co-services">
            <div class="container">
                <div class="row">
                    @if($rifa->modality == 1)
                        <div class="col-md-11 col-md-push-1" id="cotas">
                            <h4 class="fh5co-number text-center">Cotas</h4>
                            <div class="row">
                                <div class="row" style="margin-top: 10px;margin-bottom: 10px;width: 100%">
                                    <div class="col-md-2 text-center"
                                         style="font-weight: bold;margin-top: 5px;margin-bottom: 5px">
                                        Total: {{$rifa->numbers()->get()->count()}}
                                    </div>
                                    <div class="col-md-2 text-center"
                                         style="color: #22e222;font-weight: bold;margin-top: 5px;margin-bottom: 5px">
                                        Disponíveis: {{$rifa->numbers()->where('status', 1)->get()->count()}}
                                    </div>
                                    <div class="col-md-2 text-center"
                                         style="color: #ffff4c;font-weight: bold;margin-top: 5px;margin-bottom: 5px">
                                        Reservadas: {{$rifa->numbers()->where('status', 2)->get()->count()}}
                                    </div>
                                    <div class="col-md-2 text-center"
                                         style="color: #f14f4f;font-weight: bold;margin-top: 5px;margin-bottom: 5px">
                                        Pagas: {{$rifa->numbers()->where('status', 3)->get()->count()}}
                                    </div>
                                </div>
                                @foreach($rifa->numbers()->get() as $number)
                                    <button class="col-md-1 text-center btnCota" type="button" data-number="{{$number->number}}" data-id="{{$number->id}}" {{$number->status !== 1 ? 'disabled' : null}} style="margin:1px; color:white; font-weight:bold;background-color:{{$number->status === 1 ? '#22e222' : ($number->status === 2 ? '#ffff4c' : '#f14f4f')}}">
                                        {{sprintf("%03d", $number->number)}}
                                    </button>
                                @endforeach
                            </div>
                        </div>
                    @else
                        <div class="col-12 col text-center" id="cotas-aleatorias">
                            <h4 class="fh5co-number">Cotas - R$ {{$rifa->price}} cada!</h4>
                            <div id="has-fixed">
                                <div class="col text-center">
                                    <p class="text-center h2" style="margin-top: 10px;margin-bottom: 10px">
                                        Premiações Instântaneas
                                    </p>
                                    <span class="text-center h3">Seja premiado instantaneamente se receber um dos números abaixo!</span>
                                </div>
                                <div class="row d-flex justify-content-around my-5">
                                    @foreach((explode(";", $rifa->fixed_numbers)) as $number)
                                        <div class="border border-primary col-md-2 py-3 center">
                                            {{ $number }}
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                            <div class="mt-3">
                                <div class="col text-center">
                                    <p class="text-center h2" style="margin-top: 10px;margin-bottom: 10px">
                                        Adiquirir Cotas
                                    </p>
                                    <span class="text-center h3">Quanto mais cotas forem adquiridas, mais chances de ganhar!!</span>
                                </div>
                                <div class="row d-flex justify-content-around my-5">
                                    <button class="col-md-2 btn btn-primary p-5 mt-3" id="add1" type="button"> Adicionar
                                        1 cota
                                    </button>
                                    <button class="col-md-2 btn btn-primary p-5 mt-3" id="add5" type="button"> Adicionar
                                        5 cotas
                                    </button>
                                    <button class="col-md-2 btn btn-primary p-5 mt-3" id="add10" type="button">
                                        Adicionar 10 cotas
                                    </button>
                                    <button class="col-md-2 btn btn-primary p-5 mt-3" id="add50" type="button">
                                        Adicionar 50 cotas
                                    </button>
                                    <button class="col-md-2 btn btn-primary p-5 mt-3" id="add100" type="button">
                                        Adicionar 100 cotas
                                    </button>
                                </div>
                                    @csrf
                                    <input type="hidden" name="rifa_id" value="{{$rifa->id}}">
                                    <input type="hidden" name="customer_id" id="customer_id">
                                    <div class="row d-flex justify-content-center mt-3">
                                        <label class="col-12 p-5 mt-3 h3 text-center">Quantidade de Cotas</label>
                                        <input class="col-2 p-4 mt-3 text-center h3" id="qtd_cotas" name="qtd_cotas" type="number" value="0"
                                               min="1" max="{{$rifa->numbers()->where('status', 1)->get()->count()}}">
                                    </div>
                                    <div class="row d-flex justify-content-center mt-3">
                                        <p class="col-12 p-5 mt-3 h3 text-center" id="valor">R$ 0,00</p>
                                        <div class="row col-12 d-flex justify-content-center my-3">
                                            <button class="col-md-2 btn btn-primary p-5 mt-3 btnCotaAleatoria"
                                                type="button" > Comprar Cotas
                                            </button>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    @endif
                </div>
                </div>
            </div>
            <div id="reserveModal" class="modal" style="position: fixed;">
                <div class="modal-content">
                    <div class="modal-header">
                        <span class="close">&times;</span>
                        <h3 class="modal-title text-center"></h3>
                    </div>
                    <form method="POST" action="/reserveCota">
                        @csrf
                        <div class="modal-body">
                            <input type="hidden" name="customer_id" id="customer_id">
                            <input type="hidden" name="number_id" id="number_id">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="cpf" id="cpf" required class="form-control"
                                           placeholder="CPF">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" disabled name="name" id="name" required class="form-control"
                                           placeholder="Nome">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" disabled name="phone" id="phone" required class="form-control"
                                           placeholder="Telefone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="email" disabled name="email" id="email" required class="form-control"
                                           placeholder="Email">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="col-md-12 text-center">
                                <div class="form-group">
                                    <input type="submit" disabled id="reserveCota" value="Enviar"
                                           class="btn btn-primary">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <div id="randomReserveModal" class="modal" style="position: fixed;">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="close">&times;</span>
                    <h3 class="modal-title text-center"></h3>
                </div>
                <form method="POST" action="/reserveCotaAleatoria">
                    @csrf
                    <div class="modal-body">
                        <input type="hidden" name="rifa_id" value="{{$rifa->id}}">
                        <input type="hidden" name="customer_id" id="customer_id">
                        <input type="hidden" name="qtd_cotas" id="qtd_cotas">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" name="cpf" id="cpf" required class="form-control"
                                       placeholder="CPF">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" disabled name="name" id="name" required class="form-control"
                                       placeholder="Nome">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" disabled name="phone" id="phone" required class="form-control"
                                       placeholder="Telefone">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" disabled name="email" id="email" required class="form-control"
                                       placeholder="Email">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="col-md-12 text-center">
                            <div class="form-group">
                                <input type="submit" disabled id="reserveCotaAleatoria" value="Enviar"
                                       class="btn btn-primary">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
            @if(request('confirmed'))
                <div id="confirmationModal" class="modal" style="display:block">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title text-center">{{request('confirmed') === 'confirmar' ? "Reserva Efetuada!" : "Oooops, ocorreu um problema :("}}</h3>
                        </div>
                        <div class="modal-body">
                            @if (request('confirmed') === 'confirmar')
                                <div class="row text-center">
                                    <h4 style="margin-bottom: 15px">Reserva efetuada com sucesso, seguem abaixo os dados
                                        para pagamento via pix do valor referente à(s) cotas.</h4>
                                    <h5 class="col-12 py-3">Lembramos que as reservas não pagas em até 1 dias, serão canceladas.</h5>
                                    <h4 class="col-12 py-3">Após o pagamento, confira os seus números na página "Meus Números", informando seu CPF para consulta.</h4>
                                </div>
                                <div class="row">
                                    <!-- show qrcode -->
                                    <div class="col-md-12">
                                        <div class="qrcode-container">
                                            <div class="col-12 text-center">
                                                <img src="data:image/png;base64, {{request('qrCode')['encodedImage']}}" style="width: inherit;max-width: 300px"/>
                                                <!-- button to copy value to clipboard -->
                                                <input type="hidden" id="qrcode-value" value="{{request('qrCode')['qrCode']}}">
                                                <button class="btn btn-primary col-12" id="qrcode-copy-button">Copiar Código</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endif
                            @if (request('confirmed') === 'erro')
                                <div class="row text-center">
                                    <h4 style="margin-bottom: 10px">Reserva não efetuada, verifique a cota selecionada e
                                        os dados informados e tente novamente. Caso o erro persista, entre em contato
                                        conosco.</h4>
                                </div>
                            @endif
                        </div>
                        <div class="modal-footer">
                            <div class="col-md-12 text-center">
                                <div class="form-group">
                                    <a type="button" href="#cotas" id="fecharModal" class="btn btn-primary">Fechar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    @endif
    <script>
        $(function ($) {
            var $Cpf = $("input[name=cpf]");
            $Cpf.mask('000.000.000-00', {
                reverse: true
            });
            var $phone = $("input[name=phone]");
            $phone.mask("00 00000-0000", {
                reverse: true
            });

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('.btnCota').on('click', function (e) {
                $("#customer_id").val(null);
                $("#number_id").val(null);
                $("input[name=cpf]").val(null);
                $("input[name=name]").val(null);
                $("input[name=phone]").val(null);
                $("input[name=email]").val(null);
                $('#reserveModal').modal('show');
                var number = $(this).data('number');
                var id = $(this).data('id');
                $("#number_id").val(id);
                $(".modal-title").text("Reserva de cota número " + number);
                $('.modal-backdrop').remove();
            });

            $('.btnCotaAleatoria').on('click', function (e) {
                $("#customer_id").val(null);
                $("#number_id").val(null);
                $("input[name=cpf]").val(null);
                $("input[name=name]").val(null);
                $("input[name=phone]").val(null);
                $("input[name=email]").val(null);
                $('#randomReserveModal').modal('show');
                var qtd_cotas = new Array(); $("input[name=qtd_cotas]").each(function() { qtd_cotas.push($(this).val()); });
                qtd_cotas = qtd_cotas.join('');
                $("[name=qtd_cotas]").val(qtd_cotas);
                $(".modal-title").text("Reserva de " + qtd_cotas + " cotas");
                $('.modal-backdrop').remove();
            });

            $('.close').on('click', function (e) {
                $('#reserveModal').modal('hide');
            });

            $('#fecharModal').on('click', function (e) {
                $('#confirmationModal').css("display", "none");
            });

            $('input[name=cpf]').keyup(function () {
                console.log('aqui');
                var $Cpf = new Array(); $("input[name=cpf]").each(function() { $Cpf.push($(this).val()); });
                $Cpf = $Cpf.join('');
                if ($Cpf.length === 14) {
                    $Cpf = $Cpf.replace(/[^\w\s]/gi, '')
                    $.get(`/getCustomerByCpf/${$Cpf}`, {}, function (response) {
                        if (Object.keys(response).length > 0) {
                            $("input[name=name]").val(response[0].fullName);
                            $("input[name=phone]").val(response[0].phone);
                            $("input[name=email]").val(response[0].email);
                            $("[name=customer_id]").val(response[0].id);
                            $("#reserveCota").prop("disabled", false);
                            $("#reserveCotaAleatoria").prop("disabled", false);
                            $("input[name=name]").prop("disabled", false);
                            $("input[name=phone]").prop("disabled", false);
                            $("input[name=email]").prop("disabled", false);
                        } else {
                            $("input[name=name]").prop("disabled", false);
                            $("input[name=phone]").prop("disabled", false);
                            $("input[name=email]").prop("disabled", false);
                            $("#reserveCota").prop("disabled", false);
                            $("#reserveCotaAleatoria").prop("disabled", false);
                            $("#customer_id").val(null);
                            $("input[name=name]").val(null);
                            $("input[name=phone]").val(null);
                            $("input[name=email]").val(null);
                        }
                    }, 'json');
                } else {
                    $("#customer_id").val(null);
                    $("input[name=name]").prop("disabled", true);
                    $("input[name=phone]").prop("disabled", true);
                    $("input[name=email]").prop("disabled", true);
                    $("input[name=name]").val(null);
                    $("input[name=phone]").val(null);
                    $("input[name=email]").val(null);
                }
            })

            $('#add1').on('click', function (e) {
                var $qtd_cotas = $("#qtd_cotas");
                $qtd_cotas.val(parseInt($qtd_cotas.val()) + 1);
                console.log({{$rifa->price}});
                document.getElementById("valor").innerText = "R$ " + parseFloat(parseInt($qtd_cotas.val()) * parseFloat({{str_replace(',', '.', $rifa->price)}})).toFixed(2).replace('.', ',');
            })

            $('#add5').on('click', function (e) {
                var $qtd_cotas = $("#qtd_cotas");
                $qtd_cotas.val(parseInt($qtd_cotas.val()) + 5);
                document.getElementById("valor").innerText = "R$ " + parseFloat(parseInt($qtd_cotas.val()) * parseFloat({{str_replace(',', '.', $rifa->price)}})).toFixed(2).replace('.', ',');
            })

            $('#add10').on('click', function (e) {
                var $qtd_cotas = $("#qtd_cotas");
                $qtd_cotas.val(parseInt($qtd_cotas.val()) + 10);
                document.getElementById("valor").innerText = "R$ " + parseFloat(parseInt($qtd_cotas.val()) * parseFloat({{str_replace(',', '.', $rifa->price)}})).toFixed(2).replace('.', ',');
            })

            $('#add50').on('click', function (e) {
                var $qtd_cotas = $("#qtd_cotas");
                $qtd_cotas.val(parseInt($qtd_cotas.val()) + 50);
                document.getElementById("valor").innerText = "R$ " + parseFloat(parseInt($qtd_cotas.val()) * parseFloat({{str_replace(',', '.', $rifa->price)}})).toFixed(2).replace('.', ',');
            })

            $('#add100').on('click', function (e) {
                var $qtd_cotas = $("#qtd_cotas");
                $qtd_cotas.val(parseInt($qtd_cotas.val()) + 100);
                document.getElementById("valor").innerText = "R$ " + parseFloat(parseInt($qtd_cotas.val()) * parseFloat({{str_replace(',', '.', $rifa->price)}})).toFixed(2).replace('.', ',');
            })

            $('#qtd_cotas').on('change', function (e) {
                var $qtd_cotas = $("#qtd_cotas");
                document.getElementById("valor").innerText = "R$ " + parseFloat(parseInt($qtd_cotas.val()) * parseFloat({{str_replace(',', '.', $rifa->price)}})).toFixed(2).replace('.', ',');
            })

            $('#qrcode-copy-button').on('click', function (e) {
                var $qrcodeValue = $("#qrcode-value").val();
                navigator.clipboard.writeText($qrcodeValue);
            })

        })
    </script>
    @endif
@endsection
