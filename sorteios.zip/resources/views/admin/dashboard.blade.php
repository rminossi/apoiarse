@extends('admin.master.master')

@section('content')
    <div style="flex-basis: 100%;">
        <section class="dash_content_app">
            <header class="dash_content_app_header">
                <h2 class="icon-tachometer">Dashboard</h2>
            </header>
            <div class="dash_content_app_box">
                <section class="app_dash_home_stats">
                    <article class="control radius">
                        <h4 class="icon-users">Clientes Cadastrados</h4>
                        <h1 class="mt-3 text-center"><b>{{$customers->count()}}</b></h1>
                    </article>
                    <article class="blog radius">
                        <h4 class="icon-table">Rifas</h4>
                        <p class="mt-2"><b>Ativas:</b> {{$rifas->where('status', '1')->count()}}</p>
                        <p><b>Aguardando:</b> {{$rifas->where('status', '2')->count()}}</p>
                        <p><b>Encerradas:</b> {{$rifas->where('status', '3')->count()}}</p>
                    </article>
                    <article class="users radius">
                        <h4 class="icon-bar-chart">Cotas</h4>
                        <p><b>Disponibilizadas:</b> {{$numbers->count()}}</p>
                        <p><b>Disponíveis:</b> {{$numbers->where('status', '1')->count()}}</p>
                        <p><b>Compradas:</b> {{$numbers->where('status', '3')->count()}}</p>
                        <p><b>Reservadas:</b> {{$numbers->where('status', '2')->count()}}</p>
                    </article>
                </section>
            </div>
        </section>
        <section class="dash_content_app" style="margin-top: 40px;">
            <header class="dash_content_app_header">
                <h2 class="icon-hourglass">Últimas Rifas Cadastradas</h2>
            </header>
            <div class="dash_content_app_box">
                <div class="dash_content_app_box_stage">
                    <div class="realty_list">
                        @foreach($latest_rifas as $rifa)
                            <div class="realty_list_item mt-1 mb-1">
                                <div class="realty_list_item_actions_stats">
                                    <img src="{{url($rifa->cover())}}" alt="">
                                </div>
                                <div class="realty_list_item_content">
                                    <h4>{{$rifa->title}}</h4>
                                    <div class="realty_list_item_card">
                                        <div class="realty_list_item_card_image">
                                            <span class="icon-table"></span>
                                        </div>
                                        <div class="realty_list_item_card_content">
                                            <span class="realty_list_item_description_title">Cotas:</span>
                                            <span class="realty_list_item_description_content">{{$rifa->q_numbers}}</span>
                                        </div>
                                    </div>
                                    <div class="realty_list_item_card">
                                        <div class="realty_list_item_card_image">
                                            <span class="icon-money"></span>
                                        </div>
                                        <div class="realty_list_item_card_content">
                                            <span class="realty_list_item_description_title">Valor da cota:</span>
                                            <span class="realty_list_item_description_content">{{$rifa->price}}</span></span>
                                        </div>
                                    </div>
                                    <div class="realty_list_item_card">
                                        <div class="realty_list_item_card_image">
                                            <span class="icon-bar-chart"></span>
                                        </div>
                                        <div class="realty_list_item_card_content">
                                            <span class="realty_list_item_description_title">Cotas Pagas:</span>
                                            <span class="realty_list_item_description_content">{{$rifa->numbers()->where('status', '3')->count()}}</span></span>
                                        </div>
                                    </div>
                                    <div class="realty_list_item_card">
                                        <div class="realty_list_item_card_image">
                                            <span class="icon-bar-chart"></span>
                                        </div>
                                        <div class="realty_list_item_card_content">
                                            <span class="realty_list_item_description_title">Cotas Disponíveis:</span>
                                        <span class="realty_list_item_description_content">{{$rifa->numbers()->where('status', '1')->count()}}</span></span>
                                        </div>
                                    </div>
                                    <div class="realty_list_item_card">
                                        <div class="realty_list_item_card_image">
                                            <span class="icon-bar-chart"></span>
                                        </div>
                                        <div class="realty_list_item_card_content">
                                            <span class="realty_list_item_description_title">Cotas Reservadas:</span>
                                            <span class="realty_list_item_description_content">{{$rifa->numbers()->where('status', '2')->count()}}</span></span>
                                        </div>
                                    </div>
                                    @if($rifa->winner_number)
                                        <div class="realty_list_item_card">
                                            <div class="realty_list_item_card_image">
                                                <span class="icon-realty-garage"></span>
                                            </div>
                                            <div class="realty_list_item_card_content">
                                                <span class="realty_list_item_description_title">Vencedor:</span>
                                                <span class="realty_list_item_description_content">{{$rifa->winner_number}}</span></span>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                                <div class="realty_list_item_actions">
                                    <div class="ml-auto d-flex">
                                        <a href="{{route('admin.rifas.edit', ['rifa' => $rifa->id])}}" class="btn btn-green icon-pencil-square-o">Editar Rifa</a>
                                        <form method="POST" action="{{ route('admin.rifas.update', ['rifa' => $rifa->id]) }}">
                                            {{ csrf_field() }}
                                            {{ method_field('delete') }}
                                            <button class="btn btn-red icon-trash-o" type="submit">Excluir Rifa</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
