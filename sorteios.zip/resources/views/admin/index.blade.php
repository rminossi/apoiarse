<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <link rel="stylesheet" href="assets/backend/css/reset.css" />
    <link rel="stylesheet" href="assets/backend/css/boot.css" />
    <link rel="stylesheet" href="assets/backend/css/login.css" />

    <link rel="icon" type="image/png" href="assets/frontend/images/favicon.png" />
    <meta name="csrf-token" content="{{@csrf_token()}}">

    <title>Rifa Online - Painel Administrativo</title>
</head>

<body>

    <div class="ajax_response"></div>

    <div class="dash_login">
        <div class="dash_login_left" style="flex-basis: 100%">
            <article class="dash_login_left_box">
                <header class="dash_login_box_headline text-center">
                    <img src="{{url(asset('assets/frontend/images/sorteios_logo.png'))}}" width="150">
                    <h2>Entrar</h2>
                </header>
                <form name="login" action="{{route('admin.enviar-login')}}" method="post" autocomplete="off">
                    <label>
                        <span class="field icon-envelope">E-mail:</span>
                        <input type="email" name="email" placeholder="Informe seu e-mail" required />
                    </label>
                    <label>
                        <span class="field icon-unlock-alt">Senha:</span>
                        <input type="password" name="password_check" placeholder="Informe sua senha" />
                    </label>
                    <button class="gradient gradient-green radius icon-sign-in">Entrar</button>
                </form>
                <footer>
                    <p>Desenvolvido por <a href="https://www.ceossistemas.com.br">www.ceossistemas.com.br</a></p>
                    <p>&copy; <?= date("Y"); ?> - Todos os Direitos Reservados</p>
                </footer>
            </article>
        </div>
    </div>

<script src="assets/backend/js/jquery.js"></script>
<script src="assets/backend/js/login.js"></script>

</body>

</html>
