@extends('admin.master.master')
@section('content')
    <section class="dash_content_app">

        <header class="dash_content_app_header">
            <h2 class="icon-search">Cadastrar Rifa</h2>

            <div class="dash_content_app_header_actions">
                <nav class="dash_content_app_breadcrumb">
                    <ul>
                        <li><a href="">Dashboard</a></li>
                        <li class="separator icon-angle-right icon-notext"></li>
                        <li><a href="">Rifa</a></li>
                        <li class="separator icon-angle-right icon-notext"></li>
                        <li><a href="" class="text-orange">Cadastrar Rifa</a></li>
                    </ul>
                </nav>
            </div>
        </header>

        @include('admin.rifas.filter')

        <div class="dash_content_app_box">

            <div class="nav">

                @if($errors->all())
                    @foreach($errors->all() as $error)
                        <div class="message message-red">
                            <p class="icon-asterisk">{{ $error }}</p>
                        </div>
                    @endforeach
                @endif
                @if(session()->exists('message'))
                    <div class="message message-green">
                        <p class="icon-asterisk">{{ session()->get('message') }}</p>
                    </div>
                @endif
                <ul class="nav_tabs">
                    <li class="nav_tabs_item">
                        <a href="#data" class="nav_tabs_item_link active">Dados da Rifa</a>
                    </li>
                    <li class="nav_tabs_item">
                        <a href="#photos" class="nav_tabs_item_link">Imagens</a>
                    </li>
                </ul>
                <form class="app_form" action="{{route('admin.rifas.store')}}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="nav_tabs_content">
                        <div id="data">
                            <label class="label">
                                <span class="legend">*Título Site:</span>
                                <input type="text" name="title" placeholder="Insira o título da rifa" value="{{old('name')}}"/>
                            </label>
                            <div class="label">
                                <label class="label">
                                    <span class="legend">*Descrição do Sorteio:</span>
                                    <textarea name="description" cols="30" rows="10" class="mce">{{ old('description') }}</textarea>
                                </label>
                            </div>
                            <div class="label_g2">
                                <label class="label">
                                    <span class="legend">*Tipo:</span>
                                    <select name="type">
                                        <option {{ (old('type') == 'car' ? 'selected' : '') }} value="car">Carro</option>
                                        <option {{ (old('type') == 'motorcycle' ? 'selected' : '') }} value="motorcycle">Moto</option>
                                        <option {{ (old('type') == 'phone' ? 'selected' : '') }} value="phone">Telefone</option>
                                        <option {{ (old('type') == 'other' ? 'selected' : '') }} value="other">Outro</option>
                                    </select>
                                </label>
                                <label class="label">
                                    <span class="legend">*Marca/Modelo:</span>
                                    <input type="text" name="model" placeholder="Volkswagem Golf GTI" value="{{old('model')}}"/>
                                </label>
                                <label class="label ml-2">
                                    <span class="legend">*Situação:</span>
                                    <select name="prize_status">
                                        <option value="new" {{ (old('prize_status') == 'new' ? 'selected' : '') }}>Novo</option>
                                        <option value="used" {{ (old('prize_status') == 'used' ? 'selected' : '') }}>Usado</option>
                                    </select>
                                </label>
                            </div>
                            <div class="label_g4">
                                <label class="label">
                                    <span class="legend">*Quantidade de Cotas:</span>
                                    <input type="number" name="q_numbers" placeholder="Ex: 1000"
                                           value="{{old('q_numbers')}}"/>
                                </label>
                                <label class="label mr-2">
                                    <span class="legend">Valor da Cota:</span>
                                    <input type="text" name="price" placeholder="Ex: R$ 100,00"
                                           value="{{old('price')}}"/>
                                </label>
                                <label class="label">
                                    <span class="legend">*Status:</span>
                                    <select name="status">
                                        <option value="1" {{ (old('status') == '1' ? 'selected' : '') }}>Ativo</option>
                                        <option value="2" {{ (old('status') == '2' ? 'selected' : '') }}>Inativo</option>
                                        <option value="3" {{ (old('status') == '3' ? 'selected' : '') }}>Encerrado</option>
                                    </select>
                                </label>
                                <label class="label">
                                    <span class="legend">*Modalidade:</span>
                                    <select name="modality" id="modality">
                                        <option value="1" {{ (old('modality') == '1' ? 'selected' : '') }}>Número Escolhido</option>
                                        <option value="2" {{ (old('modality') == '2' ? 'selected' : '') }}>Número Aleatório</option>
                                        <option value="3" {{ (old('modality') == '3' ? 'selected' : '') }}>Número Aleatório + Fixas</option>
                                    </select>
                                </label>
                            </div>
                            <div id="fixed-numbers" class="d-none">
                                <div class="label">
                                    <label class="label">
                                        <span class="legend">*Cotas Fixas:</span>
                                        <input type="text" name="fixed_numbers" placeholder="Separar por ponto-vírgula Ex: 00000;11111;22222;..."
                                               value="{{old('fixed_numbers')}}"/>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div id="photos" class="d-none">
                            <div id="images">
                                <label class="label">
                                    <span class="legend">Imagens</span>
                                    <input type="file" name="files[]" multiple>
                                </label>
                                <div class="content_image"></div>
                                <div class="property_image">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-right mt-2">
                        <button class="btn btn-large btn-green icon-check-square-o" type="submit">Criar Rifa
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script>
        CKEDITOR.replace( 'description' );
    </script>
    <script>
        $(function () {
            $('input[name="files[]"]').change(function (files) {

                $('.content_image').text('');

                $.each(files.target.files, function (key, value) {
                    var reader = new FileReader();
                    reader.onload = function (value) {
                        $('.content_image').append(
                            '<div class="property_image_item">' +
                            '<div class="embed radius" ' +
                            'style="background-image: url(' + value.target.result + ') background-size: cover; background-position: center center;">' +
                            '</div>' +
                            '</div>');
                    };
                    reader.readAsDataURL(value);
                });
            });
            $('#modality').change(function () {
                if ($(this).val() == 3) {
                    $('#fixed-numbers').removeClass('d-none');
                } else {
                    $('#fixed-numbers').addClass('d-none');
                }
            })
        });
    </script>

@endsection
