<?php

namespace App\Http\Controllers;

use App\Models\Number;
use Illuminate\Http\Request;

class NumberController extends Controller
{
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $number = Number::where('id', $id)->first();
        $rifa_id = $number->rifa_id;
        $status = $request->status;
        if($status === 1) {
            $request->request->add(['customer_id' => null]);
        }
        $request->request->add(['status' => $status]);
        if(!$number->update($request->all())) {
            return redirect()->back()->withInput()->withErrors();
        }
        return redirect()->route('admin.rifas.edit', [
            'rifa' => $rifa_id,
            'numbers' => true
        ])->with(['message' => 'Rifa atualizada com sucesso!']);
    }
}
