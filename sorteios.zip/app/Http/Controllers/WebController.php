<?php

namespace App\Http\Controllers;

use App\Mail\Contact;
use App\Models\Customer;
use App\Models\Number;
use App\Models\Rifa;
use App\Models\Site;
use App\Services\AsaasService;
use App\Services\MercadoPagoService;
use App\Support\Seo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;


class WebController extends Controller
{

    public function __construct(Seo $seo, AsaasService $asaasService, MercadoPagoService $mercadoPagoService)
    {
        $this->seo = $seo;
        $this->asaasService = $asaasService;
        $this->mercadoPagoService = $mercadoPagoService;
        $site = Site::where('id', '1')->first();
        Session::put('site-data', $site);
        Session::save();
    }

    public function home()
    {
        $activeRifas = Rifa::where('status', 1)->orderBy('created_at', 'DESC')->limit(3)->get();
        $finishedRifas = Rifa::where('status', 3)->orderBy('created_at', 'DESC')->limit(3)->get();
        $head = $this->seo->render(
            'Rifa Online - Participe de rifas com maior segurança!',
            "Rifa Online - Participe de rifas com maior segurança!",
            url('/'),
            asset('assets/frontend/images/sorteios_logo.png')
        );
        return view('web.home', [
            'head' => $head,
            'activeRifas' => $activeRifas,
            'finishedRifas' => $finishedRifas,
        ]);
    }

    public function rifas()
    {
        $activeRifas = Rifa::where('status', 1)->orderBy('created_at', 'DESC')->get();
        $finishedRifas = Rifa::where('status', 3)->orderBy('created_at', 'DESC')->get();
        $head = $this->seo->render(
            'Rifa Online - Nossas Rifas',
            'Rifa Online - Nossas Rifas',
            route('web.rifas'),
            asset('assets/frontend/images/sorteios_logo.png')
        );
        return view('web.rifas', [
            'head' => $head,
            'activeRifas' => $activeRifas,
            'finishedRifas' => $finishedRifas,
        ]);
    }

    public function rifa($slug, $confirmed = null)
    {
        $rifa = Rifa::where('slug', $slug)->first();
        $site = Site::where('id', '1')->first();
        $head = $this->seo->render(
            "Rifa Online - $rifa->title",
            $rifa->description,
            route('web.rifa', $rifa->slug),
            asset('assets/frontend/images/sorteios_logo.png')
        );
        if ($confirmed) {
            return view('web.rifa', [
                'head' => $head,
                'rifa' => $rifa,
                'site' => $site,
                'confirmed' => $confirmed
            ]);
        } else {
            return view('web.rifa', [
                'head' => $head,
                'rifa' => $rifa
            ]);
        }
    }

    public function contato()
    {
        $site = Site::where('id', '1')->first();
        $head = $this->seo->render(
            'Rifa Online- Contato',
            'Rifa Online- Contato',
            route('web.contato'),
            asset('assets/frontend/images/sorteios_logo.png')
        );
        return view('web.contato', [
            'site' => $site,
            'head' => $head
        ]);
    }

    public function enviarContato(Request $request)
    {
        $data = [
            'reply_name' => $request->fullname,
            'reply_email' => $request->email,
            'message' => $request->message,
        ];
        Mail::send(new Contact($data));
        return redirect()->route('contato');
        //return new Contact($data);
    }

    public function getCustomerByCpf($cpf)
    {
        $customer = Customer::where('cpf', $cpf)->get();

        if (!empty($customer)) {
            return $customer;
        } else {
            return null;
        }
    }

    public function reserveCota(Request $request)
    {
        $customer_id = $this->updateOrInsertCustomer($request);
        $numbers = explode(',', $request->number_id);
        $customer = Customer::find($customer_id);
        $rifa = Rifa::whereHas('numbers', function ($query) use ($numbers) {
            $query->whereIn('id', array($numbers)[0]);
        })->first();
        DB::beginTransaction();
        foreach ($numbers as $number) {
            $number = Number::where('id', $number)->where('rifa_id', $rifa->id)->first();
            if ($number->status !== 1) {
                DB::rollBack();

                return redirect()->route('web.rifa', [
                    'slug' => $request->slug,
                    'confirmed' => 'erro',
                ]);

            }
            $number->update([
                'status' => 2,
                'customer_id' => $customer_id
            ]);
        }

        $unitPrice = $rifa->price;
        $unitPrice = str_replace('.', '', $unitPrice);
        $unitPrice = str_replace(',', '.', $unitPrice);
        $valor = count($numbers) * $unitPrice;

        if ($valor > 200) {
            $cobranca = $this->getPixQrCodeAsaas($customer, $valor);

            foreach ($numbers as $number) {
                $number = Number::where('id', $number)->where('rifa_id', $rifa->id)->first();
                $number->update([
                    'asaas_operation_id' => $cobranca['operation_id']
                ]);
            }
        } else {
            $cobranca = $this->getQrCodeMercadoPago($customer, $valor);
            foreach ($numbers as $number) {
                $number = Number::where('id', $number)->where('rifa_id', $rifa->id)->first();
                $number->update([
                    'mp_operation_id' => $cobranca['operation_id']
                ]);
            }
        }

        DB::commit();

        return redirect()->route('web.rifa', [
            'slug' => $rifa->slug,
            'confirmed' => 'confirmar',
            'qrCode' => $cobranca['qrCode']
        ]);
    }

    //reserve random numbers, like the function reserve, the quantity of numbers must be received by parameter
    public function reserveRandomNumbers(Request $request)
    {
        $numbers = $this->getRandomNumbers($request->qtd_cotas, $request->rifa_id);
        $customer_id = $this->updateOrInsertCustomer($request);
        $rifa = Rifa::find($numbers[0]->rifa_id);
        $customer = Customer::find($customer_id);
        $valor = intval($request->qtd_cotas) * floatval(str_replace(',', '.', $rifa->price));

        if ($valor > 200) {
            $cobranca = $this->getPixQrCodeAsaas($customer, $valor);

            foreach ($numbers as $number) {
                $number = Number::where('id', $number->id)->where('rifa_id', $rifa->id)->first();
                $number->update([
                    'status' => 2,
                    'customer_id' => $customer_id,
                    'asaas_operation_id' => $cobranca['operation_id']
                ]);
            }
        } else {
            $cobranca = $this->getQrCodeMercadoPago($customer, $valor);

            foreach ($numbers as $number) {
                $number = Number::where('id', $number->id)->where('rifa_id', $rifa->id)->first();
                $number->update([
                    'status' => 2,
                    'customer_id' => $customer_id,
                    'mp_operation_id' => $cobranca['operation_id']
                ]);
            }
        }

        return redirect()->route('web.rifa', [
            'slug' => $rifa->slug,
            'confirmed' => 'confirmar',
            'qrCode' => $cobranca['qrCode']
        ]);
    }

    private function updateOrInsertCustomer(Request $request)
    {
        $customer_id = null;
        if ($request->customer_id) {
            $customer = Customer::where('id', $request->customer_id)->first();
            $customer->update([
                'fullName' => $request->name,
                'phone' => $request->phone,
                'email' => $request->email
            ]);
            if ($customer->asaas_id) {
                $this->asaasService->updateCustomer($customer->asaas_id, $customer->fullName, $customer->phone, $customer->email);
            }
            $customer_id = $customer->id;
        } else {
            $customer = Customer::create([
                'cpf' => $request->cpf,
                'fullName' => $request->name,
                'phone' => $request->phone,
                'email' => $request->email
            ]);
//            $asaas_customer = $this->asaasService->createCustomer($customer->fullName, $customer->cpf, $customer->email, $customer->phone, $customer_id);
//            $customer->update([
//                'asaas_id' => $asaas_customer['id']
//            ]);
            $customer_id = $customer->id;
        }

        return $customer_id;
    }

    private function getRandomNumbers($numbers_quantity, $rifa_id)
    {
        $numbers = Number::where('status', 1)->where('rifa_id', $rifa_id)->get();
        $numbers = $numbers->random($numbers_quantity);
        return $numbers;
    }

    public function meusNumeros(Request $request)
    {
        $cpf = $request->cpf;
        if ($cpf) {
            $customer = Customer::where('cpf', $cpf)->first();
            $rifas = Rifa::whereHas('numbers', function ($query) use ($customer) {
                $query->where('customer_id', $customer->id)
                    ->where('status', 3);
            })->get();
            return view('web.meus_numeros', [
                'customer' => $customer,
                'rifas' => $rifas
            ]);
        }
        return view('web.meus_numeros');

    }

    /**
     * @param $customer
     * @param float|int $valor
     * @return array
     */
    public function getQrCodeMercadoPago($customer, float|int $valor): array
    {
        $cobranca = json_decode($this->mercadoPagoService->generatePixPayment($customer->fullName, $customer->email, $customer->phone, $customer->cpf, $customer->id, $valor));
        $qrCode['qrCode'] = $cobranca->data->code;
        $qrCode['encodedImage'] = $cobranca->data->base64;
        $operation_id = $cobranca->data->operation_id;
        return [
            "qrCode" => $qrCode,
            "operation_id" => $operation_id
        ];
    }

    /**
     * @param $customer
     * @param float|int $valor
     * @return mixed
     */
    public function getPixQrCodeAsaas($customer, float|int $valor): mixed
    {
        $cobranca = $this->asaasService->criarCobranca($customer->asaas_id, $valor, 'Rifa Online', now()->addDays(1)->format('Y-m-d'));
        $qrCode = $this->asaasService->gerarPixQrCode($cobranca['id']);
        return [
            "qrCode" => $qrCode,
            "operation_id" => $cobranca['id']
        ];
    }
}
