<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Number;
use App\Models\Rifa;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{

    public function showRegisterForm() {
        return view('admin.register');
    }

    protected function register(Request $request)
    {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);
            return redirect()->route('admin.login');
    }

    public function showLoginForm() {
        if(Auth::check() === true) {
            return redirect()->route('admin.home');
        }
        return view('admin.index');
    }
    public function home() {
        $rifas = Rifa::all();
        $numbers = Number::all();
        $customers = Customer::all();
        $latest_rifas = Rifa::orderBy('created_at','DESC')->limit(3)->get();
        return view('admin.dashboard', [
            'rifas' => $rifas,
            'numbers' => $numbers,
            'customers' => $customers,
            'latest_rifas' => $latest_rifas,
        ]);
    }

    public function login(Request $request)
    {
        if(in_array('', $request->only('email', 'password'))) {
            $json['message'] = $this->message->error('Informe todos os dados para avançar ;)')->render();
            return response()->json($json);
        }
        if(!filter_var($request->email, FILTER_VALIDATE_EMAIL)) {
            $json['message'] = $this->message->error('Email inválido')->render();
            return response()->json($json);
        }

        $credentials = [
            'email' => $request->email,
            'password' => $request->password,
        ];

        if(!Auth::attempt($credentials)) {
            $json['message'] = $this->message->error('Email ou senha inválidos, favor checar os dados.')->render();
            return response()->json($json);
        }
        $this->authenticated($request->getClientIp());
        $json['redirect'] = route('admin.home');
        return response()->json($json);
    }

    public function logout() {
        Auth::logout();
        return redirect()->route('admin.login');
    }

    private function authenticated(string $ip) {
        $user = User::where('id', Auth::user()->id);
        $user->update([
            'last_login_at' => date('Y-m-d H:i:s'),
            'last_login_ip' => $ip
        ]);
    }
}
