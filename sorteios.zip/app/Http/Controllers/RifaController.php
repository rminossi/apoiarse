<?php

namespace App\Http\Controllers;

use App\Http\Requests\Rifa as RifaRequest;
use App\Models\Image;
use App\Models\ImageRifa;
use App\Models\Number;
use App\Models\Rifa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class RifaController extends Controller
{
    public function index(){
        $rifas = Rifa::all();
        return view('admin.rifas.index')->with('rifas', $rifas);
    }

    public function show($slug){
        $rifa = Rifa::where('slug', $slug)->get();

        if (!empty($rifa)) {
            return view('admin.rifas.show')->with('rifas', $rifa);
        } else {
            return view('admin.rifas.index');
        }

    }

    public function create(){
        return view('admin.rifas.create');
    }

    public function numbers_create($ini, $fin, $rifa_id, $price) {
        for ($i=$ini; $i < $fin; $i++) {
            Number::create(['number' => $i+1, 'status'=> 1, 'rifa_id' => $rifa_id]);

        }
    }

    public function store(RifaRequest $request){

        $user = auth()->user();
        $request->request->add(['created_by' => $user->id]);
        $rifa = Rifa::create($request->all());
        $request->request->add(['rifa_id' => $rifa->id]);
        $rifa->setSlug();

        if($request->allFiles()) {
            foreach ($request->allFiles()['files'] as $image) {
                $ext = $image->getClientOriginalExtension();
                $filename = uniqid().'.'.$ext;
                $image->storeAs("public/rifas/", $filename);
                Storage::delete("public/rifas/{$rifa->image}");
                $newImage = Image::create([
                    'original_name' => $image->getClientOriginalName(),
                    'path' => "rifas/" . $filename
                ]);
                ImageRifa::create([
                    'image_id' => $newImage->id,
                    'rifa_id' => $rifa->id,
                ]);
            }
        }
        $this->numbers_create(0, $rifa->q_numbers, $rifa->id, $rifa->price);

        return redirect()->route('admin.rifas.index', [
            'rifas' => $rifa->id
        ])->with(['message' => 'Rifa cadastrada com sucesso!']);
    }

    public function edit($id){
        $rifa = Rifa::where('id', $id)->first();
        $numbers = $rifa->numbers()->get();
        if (!empty($rifa)) {
            return view('admin.rifas.edit', [
                'rifa' => $rifa,
                'numbers' => $numbers
            ]);
        } else {
            return view('admin.rifas.index');
        }
    }

    public function cancelReserve() {
        $numbers = Number::where('status', 2);
        foreach ($numbers as $number){
            $dataReserva = date_create($number->updated_at);
            $dataHoje = date_create();
            $resultado = date_diff($dataReserva, $dataHoje);
            if ($number->status === 2 && $resultado === 5) {
                $number->status = 1;
            }
        }
    }

    public function update(Request $request, Rifa $rifa){
        if($request->allFiles()) {
            foreach ($request->allFiles()['files'] as $image) {
                $ext = $image->getClientOriginalExtension();
                $filename = uniqid().'.'.$ext;
                $image->storeAs("public/rifas/", $filename);
                Storage::delete("public/rifas/{$rifa->image}");
                $newImage = Image::create([
                    'original_name' => $image->getClientOriginalName(),
                    'path' => "rifas/" . $filename
                ]);
                ImageRifa::create([
                    'image_id' => $newImage->id,
                    'rifa_id' => $rifa->id,
                ]);
            }
        }
        if(!$rifa->update($request->all())) {
            return redirect()->back()->withInput()->withErrors();
        }

        $rifa->setSlug();

        return redirect()->route('admin.rifas.edit', [
           'rifa' => $rifa->id
        ])->with(['message' => 'Rifa atualizada com sucesso!']);
    }

    public function imageSetCover(Request $request)
    {
        $imageSetCover = ImageRifa::where('id', $request->image)->first();
        $allImage = ImageRifa::where('rifa_id', $imageSetCover->rifa_id)->get();

        foreach ($allImage as $image) {
            $image->cover = false;
            $image->save();
        }

        $imageSetCover->cover = true;
        $imageSetCover->save();

        $json = [
            'success' => true,
        ];

        return response()->json($json);
    }

    public function removeImage(Request $request){
        $imageDelete = ImageRifa::where('id', $request->image)->first();
        Storage::delete($imageDelete->path);
        $imageDelete->delete();
        $json = [
            'success' => true
        ];
        return response()->json($json);
    }

    public function destroy(Rifa $rifa){
        $rifa->delete();
        return redirect()-> route('admin.rifas.index')->with(['message' => 'Rifa deletada com sucesso!']);

    }
}
