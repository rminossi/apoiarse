<?php

namespace App\Services;

class CotaService
{

    public function __construct()
    {
    }


    public function reserveCota($cota, $customer_id)
    {

    }

}
