<?php

namespace App\Models;

use Cviebrock\EloquentSluggable\Services\SlugService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Rifa extends Model
{
    protected $fillable = [
        'title',
        'description',
        'model',
        'prize_status',
        'price',
        'q_numbers',
        'draw_date',
        'status',
        'winner_number',
        'created_by',
        'slug',
        'type',
        'modality',
        'fixed_numbers',
    ];

    protected $casts = [
        'draw_date' => 'date',
        'fixed_numbers' => 'array'
    ];

    public function images()
    {
        return $this->hasMany(ImageRifa::class, 'rifa_id')->orderBy('cover', 'ASC');
    }

    public function numbers()
    {
        return $this->hasMany(Number::class, 'rifa_id');
    }

    public static function boot()
    {
        parent::boot();

        static::deleting(function ($rifa) { // before delete() method call this
            $rifa->numbers()->delete();
            $rifa->images()->delete();
            // do the rest of the cleanup...
        });
    }

    public function cover()
    {
        $cover = $this->images()->where('cover', 1)->first();

        if (empty($cover)) {
            $path = Image::find($this->images()->first()->image_id)->path;

            return Storage::url('public/' . $path);
        }

        $path = Image::find($cover['image_id']);
        return Storage::url('public/' . $path->path);
    }

    public function setDrawDateAttribute($value)
    {
        $this->attributes['draw_date'] = $this->convertStringToDate($value);
    }

    public function setPriceAttribute($value)
    {
        $this->attributes['price'] = floatval($this->convertStringToDouble($value));
    }

    public function setSlug()
    {
        if (!empty($this->title)) {
            $this->attributes['slug'] = Str::slug(Rifa::class, 'slug', $this->title) . '-' . $this->id;
            $this->save();
        }
    }

    public function getPriceAttribute($value)
    {
        return number_format($value, '2', ',', '.');
    }

    private function convertStringToDate(?string $param)
    {
        if (empty($param)) {
            return null;
        }
        list($day, $month, $year) = explode('/', $param);
        return (new \DateTime($year . '-' . $month . '-' . $day))->format('Y-m-d');
    }

    private function convertStringToDouble(?string $param)
    {
        if (empty($param)) {
            return null;
        }
        return str_replace(',', '.', str_replace('.', '', $param));
    }
};
