<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $fillable = [
        'fullName',
        'email',
        'cpf',
        'phone',
        'asaas_id'
    ];

    public function setCPFAttribute($value)
    {
        $this->attributes['cpf'] = preg_replace('/[^A-Za-z0-9]/', '', $value);
    }
    public function getCpfAttribute($value)
    {
        return substr($value, 0, 3) . '.' . substr($value, 3, 3) . '.' . substr($value, 6, 3) . '-' . substr($value, 9, 2);
    }

    public function setPhoneAttribute($value)
    {
        $this->attributes['phone'] = preg_replace('/[^A-Za-z0-9]/', '', $value);
    }

    public function getPhoneAttribute($value)
    {
        return substr($value, 0, 2) . ' ' . substr($value, 2, 5) . '-' . substr($value, 7, 4);
    }

    public function numbers()
    {
        return $this->hasMany(Number::class);
    }


}
