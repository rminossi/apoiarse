<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Pivot;
use Illuminate\Support\Facades\Storage;

class ImageRifa extends Pivot
{
    protected $fillable = [
        'image_id',
        'rifa_id',
        'cover',
        'path'
    ];

    public function getUrlAttribute()
    {
        return Storage::url('rifas/'.$this->path);
    }

    public function image()
    {
        return $this->belongsTo(Image::class);
    }
}
