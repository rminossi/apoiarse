<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Number extends Model
{
    protected $fillable = ['number', 'price', 'rifa_id', 'status', 'customer_id', 'asaas_operation_id', 'mp_operation_id'];

    public function rifa()
    {
        return $this->belongsTo(Rifa::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function setPriceAttribute($value)
    {
        $this->attributes['price'] = floatval($this->convertStringToDouble($value));
    }

    private function convertStringToDouble(?string $param)
    {
        if(empty($param)){
            return null;
        }
        return str_replace(',', '.', str_replace('.', '', $param));
    }
}
