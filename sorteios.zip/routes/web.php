<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\NumberController;
use App\Http\Controllers\RifaController;
use App\Http\Controllers\SiteController;
use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::post('/enviar-contato', [WebController::class, 'enviarContato'])->name('enviar-contato');

Route::group(['namespace' => 'Web', 'as' => 'web.'], function () {
    Route::get('/', [WebController::class, 'home'])->name('home');
    Route::get('/rifas', [WebController::class, 'rifas'])->name('rifas');
    Route::get('/rifas/{slug}', [WebController::class, 'rifa'])->name('rifa');
    Route::get('/contato', [WebController::class, 'contato'])->name('contato');
    Route::get('/getCustomerByCpf/{cpf}', [WebController::class, 'getCustomerByCpf'])->name('getCustomerByCpf');
    Route::post('/reserveCota', [WebController::class, 'reserveCota'])->name('reserveCota');
    Route::post('/reserveCotaAleatoria', [WebController::class, 'reserveRandomNumbers'])->name('reserveCotaAleatoria');
    Route::get('/meus-numeros', [WebController::class, 'meusNumeros'])->name('my-numbers');
});

Route::group(['prefix' => 'admin', 'as' => 'admin.'], function () {
   Route::get('/', [AuthController::class, 'showLoginForm'])->name('login');
   Route::get('/xlkaoiyt/register', [AuthController::class, 'showRegisterForm'])->name('register');
   Route::post('/login', [AuthController::class, 'login'])->name('enviar-login');
   Route::post('/register', [AuthController::class, 'register'])->name('enviar-registro');
   Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
   Route::get('/cancelReserve', [AuthController::class, 'cancelReserve'])->name('cancelReserve');
   Route::group(['middleware' => ['auth']], function () {
       Route::get('home', [AuthController::class, 'home'])->name('home');
       Route::resource('site', SiteController::class);
       Route::resource('customers', CustomerController::class);
       Route::resource('rifas', RifaController::class);
       Route::resource('numbers', NumberController::class);
       Route::delete('remove-image', [RifaController::class, 'removeImage'])->name('rifas.removeImage');
       Route::post('image-set-cover', [RifaController::class, 'imageSetCover'])->name('rifas.imageSetCover');
   });
});
